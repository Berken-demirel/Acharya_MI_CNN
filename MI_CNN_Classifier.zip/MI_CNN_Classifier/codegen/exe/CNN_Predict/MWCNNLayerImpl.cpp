#include "MWCNNLayerImpl.hpp"
#include "MWTargetNetworkImpl.hpp"
#include "cnn_api.hpp"
#include <cassert>
#include <cstring>
#include <stdio.h>
#include <omp.h>
 MWCNNLayerImpl::MWCNNLayerImpl(MWCNNLayer* layer, MWTargetNetworkImpl* 
ntwk_impl) : ZKjSVYDDjACizBkGbqBq(layer) , dMxIKDGTITyhdLqIHBLA(ntwk_impl) { } void 
MWCNNLayerImpl::allocate() { MWTensor* opTensor = 
getLayer()->getOutputTensor(0); for (int i = 0; i < 
getLayer()->getNumOutputs(); i++) { MWTensor* opTensor = 
getLayer()->getOutputTensor(i); if (opTensor->getopBufIndex() < 0) { 
getarmTensor(i)->allocator()->allocate(); } else {
#if defined(USE_18_11_LIBRARY) || defined(USE_19_02_LIBRARY)
 
getarmTensor(i)->allocator()->import_memory(dMxIKDGTITyhdLqIHBLA->memBuffer[opTensor->getopBufIndex()],dMxIKDGTITyhdLqIHBLA->maxBufSize 
*sizeof(float));
#else
 getarmTensor(i)->allocator()->import_memory(arm_compute::Memory(dMxIKDGTITyhdLqIHBLA->memBuffer[opTensor->getopBufIndex()]));
#endif
 } opTensor->setData((float*)getarmTensor(i)->buffer()); } } void 
MWCNNLayerImpl::cleanup() { if 
(ZKjSVYDDjACizBkGbqBq->getOutputTensor()->getopBufIndex() < 0) { for (int i = 0; i 
< getLayer()->getNumOutputs(); i++) { getarmTensor(i)->allocator()->free(); } } 
} std::string MWCNNLayerImpl::getLinuxPath(const char* fileName) { std::string 
fileS(fileName); std::string key ("\\"); std::size_t found = 0; while(found != 
std::string::npos){ found = fileS.rfind(key); if (found!=std::string::npos) 
fileS.replace (found,key.length(),"/"); } return fileS; } arm_compute::Tensor* 
MWCNNLayerImpl::getprevLayerarmTensor(MWTensor* ipTensor) { int index = 
ipTensor->getSourcePortIndex(); if (ipTensor->getOwner()->getImpl() == NULL) { 
return 
ipTensor->getOwner()->getInputTensor()->getOwner()->getImpl()->getarmTensor(index); 
} else { if (ipTensor->getOwner()->getImpl()->getarmTensor() == nullptr) { 
return 
ipTensor->getOwner()->getInputTensor()->getOwner()->getImpl()->getarmTensor( 
index); } else { return ipTensor->getOwner()->getImpl()->getarmTensor(index); } 
} } arm_compute::Tensor* MWCNNLayerImpl::getarmTensor(int index) { if 
(armTensor.size() >= 1) { return armTensor[index].get(); } else { return 
nullptr; } } void 
MWCNNLayerImpl::setarmTensor(std::shared_ptr<arm_compute::Tensor> tensor, int 
index) { armTensor[index] = tensor; } 
MWInputLayerImpl::MWInputLayerImpl(MWCNNLayer* layer, MWTargetNetworkImpl* 
ntwk_impl, int cCXqPFPPcoHzYMDpnUxQ, int XYbzSmRQGatVJtGmDZSo, int ujSEtllBwMdSJhSkFCia, int 
WprSrhAStKGxyXeoxETy, int zRhMJbzYfMHEzDwdpDGW, const char* avg_file_name, int outbufIdx) 
: MWCNNLayerImpl(layer, ntwk_impl) { createInputLayer(cCXqPFPPcoHzYMDpnUxQ, 
XYbzSmRQGatVJtGmDZSo, ujSEtllBwMdSJhSkFCia, WprSrhAStKGxyXeoxETy, zRhMJbzYfMHEzDwdpDGW, avg_file_name, 
outbufIdx); } MWInputLayerImpl::~MWInputLayerImpl() { } int tap_count = 0; void 
mw_interm_tap(arm_compute::Tensor& armTensor, int size, int count) { FILE* fp; 
int i; char str[500]; float* memBuf = (float*)calloc(size,sizeof(float)); 
fillTensorToIp((unsigned char*)memBuf,armTensor);
#define TXT_FILE 1
#if TXT_FILE
 sprintf(str, "taps/mw_interm_tap_%d.txt", count); fp = fopen(str, "w"); for (i 
= 0; i < size; i++) { fprintf(fp, "%f\n", memBuf[i]); }
#else
 sprintf(str, "taps/mw_interm_tap_%d.bin", count); fp = fopen(str, "wb"); 
fwrite(inp, 4, size, fp);
#endif
 free(memBuf); fclose(fp); } void MWInputLayerImpl::createInputLayer(int 
cCXqPFPPcoHzYMDpnUxQ, int XYbzSmRQGatVJtGmDZSo, int ujSEtllBwMdSJhSkFCia, int WprSrhAStKGxyXeoxETy, int 
zRhMJbzYfMHEzDwdpDGW, const char* avg_file_name,  int outbufIdx) { MWInputLayer* 
inpLayer = static_cast<MWInputLayer*>(getLayer()); YeIFysyIXePEVfpcANol = 
zRhMJbzYfMHEzDwdpDGW; m_inputImage = (float*)malloc(cCXqPFPPcoHzYMDpnUxQ * WprSrhAStKGxyXeoxETy * 
XYbzSmRQGatVJtGmDZSo * ujSEtllBwMdSJhSkFCia * sizeof(float)); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); 
getarmTensor()->allocator()->init( 
arm_compute::TensorInfo(arm_compute::TensorShape((long unsigned 
int)ujSEtllBwMdSJhSkFCia, (long unsigned int)XYbzSmRQGatVJtGmDZSo, (long unsigned 
int)WprSrhAStKGxyXeoxETy), 1, arm_compute::DataType::F32)); 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); int eVAFqeShtGZAZluKdMvQ = 
WprSrhAStKGxyXeoxETy * XYbzSmRQGatVJtGmDZSo * ujSEtllBwMdSJhSkFCia; if( YeIFysyIXePEVfpcANol ) { 
loadAvg(avg_file_name, eVAFqeShtGZAZluKdMvQ); } return; } void 
MWInputLayerImpl::loadAvg(const char* XCnEVUzxqcNgsuUbRonz, int eVAFqeShtGZAZluKdMvQ) 
{ std::string fileString = getLinuxPath(XCnEVUzxqcNgsuUbRonz); FILE* 
XNZmftADYzuZnIYIpBaT = MWCNNLayer::openBinaryFile(fileString.c_str()); if 
(XNZmftADYzuZnIYIpBaT == NULL) { 
std::cerr<<"Unable to open Input Average file"<<std::endl; } PmFfARVzoHVAYkfpuvqK = new 
std::vector<float>; PmFfARVzoHVAYkfpuvqK->reserve(eVAFqeShtGZAZluKdMvQ); 
if(YeIFysyIXePEVfpcANol==1){ call_fread(PmFfARVzoHVAYkfpuvqK->data(), sizeof(float), 
eVAFqeShtGZAZluKdMvQ, XNZmftADYzuZnIYIpBaT, XCnEVUzxqcNgsuUbRonz); } else{ MWInputLayer* 
inpLayer = static_cast<MWInputLayer*>(getLayer()); MWTensor* opTensor = 
inpLayer->getOutputTensor(0); int numChannels = opTensor->getChannels(); int 
channelSize = opTensor->getHeight() * opTensor->getWidth(); int 
channelOffset=0; std::vector<float> THfVbcZJtANcLKxEriuV(numChannels); 
call_fread(THfVbcZJtANcLKxEriuV.data(), sizeof(float), numChannels, XNZmftADYzuZnIYIpBaT, 
XCnEVUzxqcNgsuUbRonz); for(int i=0;i<numChannels;i++){ 
std::fill_n(PmFfARVzoHVAYkfpuvqK->begin()+channelOffset, channelSize, 
THfVbcZJtANcLKxEriuV[i]); channelOffset = channelOffset+channelSize; } } 
fclose(XNZmftADYzuZnIYIpBaT); return; } void MWInputLayerImpl::allocate() { 
MWCNNLayerImpl::allocate(); MWTensor* opTensor = 
getLayer()->getOutputTensor(0); if ((getarmTensor()->info()->total_size() / 4) 
== (opTensor->getBatchSize() * opTensor->getChannels() * opTensor->getHeight() 
* opTensor->getWidth())) { opTensor->setData((float*)getarmTensor()->buffer()); 
} else { opTensor->setData(m_inputImage); } 
opTensor->setData(getData<float>()); } void fillIpToTensor(unsigned char* 
in_buffer, arm_compute::ITensor& tensor) { uint width = 
tensor.info()->dimension(0); uint height = tensor.info()->dimension(1); int 
data_size_in_bytes = 4;  int collapsed_upper = 
tensor.info()->tensor_shape().total_size_upper(2); uint8_t* ptr_out = 
tensor.buffer() + tensor.info()->offset_first_element_in_bytes(); const 
arm_compute::Strides& strides_in_bytes = tensor.info()->strides_in_bytes(); for 
(int i = 0; i < collapsed_upper; ++i) { size_t slice_offset = i * 
strides_in_bytes.z(); for (unsigned int y = 0; y < height; ++y) { size_t 
row_offset = y * strides_in_bytes.y(); memcpy(ptr_out + slice_offset + 
row_offset, in_buffer + i * width * height * data_size_in_bytes + y * width * 
data_size_in_bytes, width * data_size_in_bytes); } } } void 
fillTensorToIp(unsigned char* out_buffer, arm_compute::ITensor& tensor) { uint 
width = tensor.info()->dimension(0); uint height = tensor.info()->dimension(1); 
int data_size_in_bytes = 4;  int collapsed_upper = 
tensor.info()->tensor_shape().total_size_upper(2); uint8_t* ptr_out = 
tensor.buffer() + tensor.info()->offset_first_element_in_bytes(); const 
arm_compute::Strides& strides_in_bytes = tensor.info()->strides_in_bytes(); for 
(int i = 0; i < collapsed_upper; ++i) { size_t slice_offset = i * 
strides_in_bytes.z(); for (unsigned int y = 0; y < height; ++y) { size_t 
row_offset = y * strides_in_bytes.y(); memcpy(out_buffer + i * width * height * 
data_size_in_bytes + y * width * data_size_in_bytes, ptr_out + slice_offset + 
row_offset, width * data_size_in_bytes); } } } void 
MWCNNLayerImpl::fillValueToTensor(float value , arm_compute::ITensor& tensor) { 
uint width = tensor.info()->dimension(0); uint height = 
tensor.info()->dimension(1); int data_size_in_bytes = 4;  int collapsed_upper = 
tensor.info()->tensor_shape().total_size_upper(2); uint8_t* ptr_out = 
tensor.buffer() + tensor.info()->offset_first_element_in_bytes(); const 
arm_compute::Strides& strides_in_bytes = tensor.info()->strides_in_bytes(); for 
(int i = 0; i < collapsed_upper; ++i) { size_t slice_offset = i * 
strides_in_bytes.z(); for (unsigned int y = 0; y < height; ++y) { size_t 
row_offset = y * strides_in_bytes.y(); float* ptr_out1 = (float*)(ptr_out + 
slice_offset + row_offset); for(int j = 0; j < width * data_size_in_bytes/4; 
j++) { ptr_out1[j] = value; } } } } void MWInputLayerImpl::predict() { float* 
inp = m_inputImage; int i, btch; MWInputLayer* inpLayer = 
static_cast<MWInputLayer*>(getLayer()); MWTensor* opTensor = 
inpLayer->getOutputTensor(0); float* out = m_inputImage; if 
((getarmTensor()->info()->total_size() / 4) == (opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth())) { inp 
= (float*)getarmTensor()->buffer(); out = (float*)getarmTensor()->buffer(); } 
else { inp = m_inputImage; out = m_inputImage; } if (YeIFysyIXePEVfpcANol) { 
for (btch = 0; btch < opTensor->getBatchSize(); btch++) {
#pragma omp parallel for
 for (i = 0; i < opTensor->getChannels() * opTensor->getHeight() * 
opTensor->getWidth(); i++) { out[i] = inp[i] - (*PmFfARVzoHVAYkfpuvqK)[i]; } inp += 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(); out += 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(); } } if 
((getarmTensor()->info()->total_size() / 4) != (opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth())) { 
fillIpToTensor((unsigned char*)m_inputImage, *getarmTensor()); }
#if MW_INPUT_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } void MWInputLayerImpl::cleanup() { MWCNNLayerImpl::cleanup(); 
free(m_inputImage); if (YeIFysyIXePEVfpcANol) { if (PmFfARVzoHVAYkfpuvqK) { delete 
PmFfARVzoHVAYkfpuvqK; } } return; } MWReLULayerImpl::MWReLULayerImpl(MWCNNLayer* layer, 
MWTargetNetworkImpl* ntwk_impl, int inPlace, int outbufIdx) : 
MWCNNLayerImpl(layer, ntwk_impl) { createReLULayer(); } 
MWReLULayerImpl::~MWReLULayerImpl() { } void MWReLULayerImpl::createReLULayer() 
{ MWReLULayer* reluLayer = static_cast<MWReLULayer*>(getLayer()); MWTensor* 
ipTensor = reluLayer->getInputTensor(); MWTensor* opTensor = 
reluLayer->getOutputTensor(); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); if 
(prevLayerarmTensor->info()->num_dimensions() == 1) { 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)opTensor->getChannels()), 1, 
arm_compute::DataType::F32)); } else { getarmTensor()->allocator()->init( 
arm_compute::TensorInfo(arm_compute::TensorShape((long unsigned 
int)ipTensor->getWidth(), (long unsigned int)ipTensor->getHeight(), (long 
unsigned int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); } 
m_actLayer.configure(prevLayerarmTensor, getarmTensor(), 
arm_compute::ActivationLayerInfo(arm_compute::ActivationLayerInfo::ActivationFunction::RELU)); 
return; } void MWReLULayerImpl::allocate() { MWTensor* opTensor = 
getLayer()->getOutputTensor(0); getarmTensor()->allocator()->allocate(); 
opTensor->setData((float*)getarmTensor()->buffer()); } void 
MWReLULayerImpl::predict() { MWReLULayer* reluLayer = 
static_cast<MWReLULayer*>(getLayer()); MWTensor* opTensor = 
reluLayer->getOutputTensor(); m_actLayer.run();
#if MW_RELU_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } MWNormLayerImpl::MWNormLayerImpl(MWCNNLayer* layer, 
MWTargetNetworkImpl* ntwk_impl, unsigned PfisSEEWDaQFynnzlcin,  double 
BUOdotSvmFyUWQKMUdra,  double BlRIQPyqJZORKENzSdYf,  double CufLFODQDXTAPyRqYodN, int outbufIdx) 
: MWCNNLayerImpl(layer, ntwk_impl) { 
createNormLayer(PfisSEEWDaQFynnzlcin, BUOdotSvmFyUWQKMUdra, 
BlRIQPyqJZORKENzSdYf, CufLFODQDXTAPyRqYodN, outbufIdx); } 
MWNormLayerImpl::~MWNormLayerImpl() { } void 
MWNormLayerImpl::createNormLayer(unsigned PfisSEEWDaQFynnzlcin, double 
BUOdotSvmFyUWQKMUdra, double BlRIQPyqJZORKENzSdYf, double CufLFODQDXTAPyRqYodN,  int outbufIdx) 
{ MWNormLayer* normLayer = static_cast<MWNormLayer*>(getLayer()); MWTensor* 
ipTensor = normLayer->getInputTensor(); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); if (ipTensor->getWidth() 
== 1 && ipTensor->getHeight() == 1) { 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)ipTensor->getChannels()), 1, 
arm_compute::DataType::F32)); } else { getarmTensor()->allocator()->init( 
arm_compute::TensorInfo(arm_compute::TensorShape((long unsigned 
int)ipTensor->getWidth(), (long unsigned int)ipTensor->getHeight(), (long 
unsigned int)ipTensor->getChannels()), 1, arm_compute::DataType::F32)); } 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); 
m_normLayer.configure(prevLayerarmTensor, getarmTensor(), 
arm_compute::NormalizationLayerInfo(arm_compute::NormType::CROSS_MAP, 
PfisSEEWDaQFynnzlcin, BUOdotSvmFyUWQKMUdra, BlRIQPyqJZORKENzSdYf, 
CufLFODQDXTAPyRqYodN)); return; } void MWNormLayerImpl::predict() { MWNormLayer* 
normLayer = static_cast<MWNormLayer*>(getLayer()); MWTensor* opTensor = 
normLayer->getOutputTensor(); m_normLayer.run();
#if MW_NORM_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } MWMaxPoolingLayerImpl::MWMaxPoolingLayerImpl(MWCNNLayer* layer, 
MWTargetNetworkImpl* ntwk_impl, int NNhshzQGJHLSGjDiVerE,  int NmExSIssnXpisMKKatUq,  
int ONvcEjLBnVNUdjMKOAwF,  int OiVqrkNdXioJhALWMMvm, int GZGFVDrXwFLJleoTDywO, int 
GFggoMvRWucDMqzlWzCl,  int LklYEpYUjaLTgcFFAaJX, int MgAiRWiTutoTMxKXjmHQ, 
bool QhTWatiCfcWYsHdkcyhZ, int eybNKlJCSDUvsznWynwK, const std::vector<int>& 
UzaGmBLFEwmwaFXebUma ) : MWCNNLayerImpl(layer, ntwk_impl) { 
assert(!QhTWatiCfcWYsHdkcyhZ); createMaxPoolingLayer(NNhshzQGJHLSGjDiVerE, 
NmExSIssnXpisMKKatUq, ONvcEjLBnVNUdjMKOAwF, OiVqrkNdXioJhALWMMvm, 
GZGFVDrXwFLJleoTDywO, GFggoMvRWucDMqzlWzCl, LklYEpYUjaLTgcFFAaJX, 
MgAiRWiTutoTMxKXjmHQ,  eybNKlJCSDUvsznWynwK, UzaGmBLFEwmwaFXebUma); } 
MWMaxPoolingLayerImpl::~MWMaxPoolingLayerImpl() { } float* 
MWMaxPoolingLayerImpl::getIndexData() { assert(false); } void 
MWMaxPoolingLayerImpl::createMaxPoolingLayer(int NNhshzQGJHLSGjDiVerE, int 
NmExSIssnXpisMKKatUq, int ONvcEjLBnVNUdjMKOAwF, int OiVqrkNdXioJhALWMMvm, int 
GZGFVDrXwFLJleoTDywO, int GFggoMvRWucDMqzlWzCl, int LklYEpYUjaLTgcFFAaJX, 
int MgAiRWiTutoTMxKXjmHQ, int eybNKlJCSDUvsznWynwK,  const std::vector<int>& 
UzaGmBLFEwmwaFXebUma) { MWMaxPoolingLayer* maxPoolLayer = 
static_cast<MWMaxPoolingLayer*>(getLayer()); MWTensor* ipTensor = 
maxPoolLayer->getInputTensor(); MWTensor* opTensor = 
maxPoolLayer->getOutputTensor(); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); 
getarmTensor()->allocator()->init(arm_compute::TensorInfo(arm_compute::TensorShape((long 
unsigned int)opTensor->getWidth(), (long unsigned int)opTensor->getHeight(), 
(long unsigned int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); 
assert(eybNKlJCSDUvsznWynwK == 1); int outbufIdx = UzaGmBLFEwmwaFXebUma[0]; 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); 
m_maxPoolLayer.configure( prevLayerarmTensor, getarmTensor(), 
arm_compute::PoolingLayerInfo( arm_compute::PoolingType::MAX, NNhshzQGJHLSGjDiVerE, 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR))); return; } 
void MWMaxPoolingLayerImpl::predict() { MWMaxPoolingLayer* maxPoolLayer = 
static_cast<MWMaxPoolingLayer*>(getLayer()); MWTensor* opTensor = 
maxPoolLayer->getOutputTensor(); m_maxPoolLayer.run();
#if MW_POOL_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } MWFCLayerImpl::MWFCLayerImpl(MWCNNLayer* layer, MWTargetNetworkImpl* 
ntwk_impl, int FpguQZSermqZCMRiUfML, const char* 
yPBlKhIGljihkXaXbYpB,  const char* UpnEytIWGokwbTFkBcSx, int outbufIdx) : 
MWCNNLayerImpl(layer, ntwk_impl) { createFCLayer(FpguQZSermqZCMRiUfML, 
yPBlKhIGljihkXaXbYpB, UpnEytIWGokwbTFkBcSx, outbufIdx); } 
MWFCLayerImpl::~MWFCLayerImpl() { } void MWFCLayerImpl::createFCLayer(int 
FpguQZSermqZCMRiUfML, const char* yPBlKhIGljihkXaXbYpB, const char* 
UpnEytIWGokwbTFkBcSx,  int outbufIdx) { MWFCLayer* fcLayer = 
static_cast<MWFCLayer*>(getLayer()); MWTensor* ipTensor = 
fcLayer->getInputTensor(); MWTensor* opTensor = fcLayer->getOutputTensor(); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); 
m_fcLayerWgtTensor.allocator()->init( 
arm_compute::TensorInfo(arm_compute::TensorShape((long unsigned 
int)(FpguQZSermqZCMRiUfML), (long unsigned 
int)(opTensor->getChannels())), 1, arm_compute::DataType::F32)); 
m_fcLayerBiasTensor.allocator()->init( 
arm_compute::TensorInfo(arm_compute::TensorShape((long unsigned 
int)(opTensor->getChannels())), 1, arm_compute::DataType::F32)); 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)(opTensor->getChannels() * 
opTensor->getBatchSize())), 1, arm_compute::DataType::F32)); 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); 
m_fcLayer.configure(prevLayerarmTensor, &m_fcLayerWgtTensor, 
&m_fcLayerBiasTensor, getarmTensor()); 
m_fcLayerWgtTensor.allocator()->allocate(); 
m_fcLayerBiasTensor.allocator()->allocate(); 
loadWeights(yPBlKhIGljihkXaXbYpB,FpguQZSermqZCMRiUfML); 
loadBias(UpnEytIWGokwbTFkBcSx); return; } void MWFCLayerImpl::loadWeights(const 
char* XCnEVUzxqcNgsuUbRonz,int FpguQZSermqZCMRiUfML) { MWFCLayer* fcLayer 
= static_cast<MWFCLayer*>(getLayer()); MWTensor* ipTensor = 
fcLayer->getInputTensor(); MWTensor* opTensor = fcLayer->getOutputTensor(); int 
FshVHIJMRAhtQirYPlZd = opTensor->getChannels(); int eVAFqeShtGZAZluKdMvQ = 
FpguQZSermqZCMRiUfML * FshVHIJMRAhtQirYPlZd;  float* 
ujSEtllBwMdSJhSkFCia = (float*)malloc(eVAFqeShtGZAZluKdMvQ * sizeof(float)); std::string 
fileString = getLinuxPath(XCnEVUzxqcNgsuUbRonz); FILE* XNZmftADYzuZnIYIpBaT = 
MWCNNLayer::openBinaryFile(fileString.c_str()); call_fread(ujSEtllBwMdSJhSkFCia, 
sizeof(float), eVAFqeShtGZAZluKdMvQ, XNZmftADYzuZnIYIpBaT, XCnEVUzxqcNgsuUbRonz); if 
(ipTensor->getHeight() != 1 && ipTensor->getWidth() != 1) { float* 
vjDFlBZzKvbpPseAtMBP = (float*)malloc(sizeof(float) * ipTensor->getHeight() * 
ipTensor->getWidth()); for (int k = 0; k < eVAFqeShtGZAZluKdMvQ / 
ipTensor->getHeight() / ipTensor->getWidth(); k++) { for (int i = 0; i < 
ipTensor->getHeight() * ipTensor->getWidth(); i++) vjDFlBZzKvbpPseAtMBP[i] = 
ujSEtllBwMdSJhSkFCia[k * ipTensor->getHeight() * ipTensor->getWidth() + i]; for (int j 
= 0; j < ipTensor->getHeight(); j++) for (int i = 0; i < ipTensor->getWidth(); 
i++) ujSEtllBwMdSJhSkFCia[k * ipTensor->getHeight() * ipTensor->getWidth() + j * 
ipTensor->getWidth() + i] = vjDFlBZzKvbpPseAtMBP[j + i * ipTensor->getHeight()]; } 
free(vjDFlBZzKvbpPseAtMBP); } std::copy_n((unsigned char*)ujSEtllBwMdSJhSkFCia, eVAFqeShtGZAZluKdMvQ 
* sizeof(float), (unsigned char*)m_fcLayerWgtTensor.buffer()); 
free(ujSEtllBwMdSJhSkFCia); fclose(XNZmftADYzuZnIYIpBaT); return; } void 
MWFCLayerImpl::loadBias(const char* XCnEVUzxqcNgsuUbRonz) { MWFCLayer* fcLayer = 
static_cast<MWFCLayer*>(getLayer()); MWTensor* opTensor = 
fcLayer->getOutputTensor(); int getNumOutputFeatures = opTensor->getChannels(); 
float* TfsmDFpPPOscKZifVzSQ = (float*)malloc(getNumOutputFeatures * sizeof(float)); 
std::string fileString = getLinuxPath(XCnEVUzxqcNgsuUbRonz); FILE* XNZmftADYzuZnIYIpBaT 
= MWCNNLayer::openBinaryFile(fileString.c_str()); int eVAFqeShtGZAZluKdMvQ = 
getNumOutputFeatures;  call_fread(TfsmDFpPPOscKZifVzSQ, sizeof(float), eVAFqeShtGZAZluKdMvQ, 
XNZmftADYzuZnIYIpBaT, XCnEVUzxqcNgsuUbRonz); std::copy_n((unsigned char*)TfsmDFpPPOscKZifVzSQ, 
eVAFqeShtGZAZluKdMvQ * sizeof(float), (unsigned char*)m_fcLayerBiasTensor.buffer()); 
free(TfsmDFpPPOscKZifVzSQ); fclose(XNZmftADYzuZnIYIpBaT); return; } void 
MWFCLayerImpl::predict() { MWFCLayer* fcLayer = 
static_cast<MWFCLayer*>(getLayer()); MWTensor* opTensor = 
fcLayer->getOutputTensor(); m_fcLayer.run();
#if MW_FC_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } void MWFCLayerImpl::cleanup() { MWCNNLayerImpl::cleanup(); 
m_fcLayerWgtTensor.allocator()->free(); 
m_fcLayerBiasTensor.allocator()->free(); return; } 
MWSoftmaxLayerImpl::MWSoftmaxLayerImpl(MWCNNLayer* layer, MWTargetNetworkImpl* 
ntwk_impl, int outbufIdx) : MWCNNLayerImpl(layer, ntwk_impl) , 
m_doesFlatten(false) { createSoftmaxLayer(outbufIdx); } 
MWSoftmaxLayerImpl::~MWSoftmaxLayerImpl() { } void 
MWSoftmaxLayerImpl::createSoftmaxLayer(int outbufIdx) { MWSoftmaxLayer* 
sfmxLayer = static_cast<MWSoftmaxLayer*>(getLayer()); MWTensor* ipTensor = 
sfmxLayer->getInputTensor(); MWTensor* opTensor = sfmxLayer->getOutputTensor(); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); if 
(prevLayerarmTensor->info()->num_dimensions() == 1) { 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)opTensor->getWidth() * (long 
unsigned int)opTensor->getHeight() * (long unsigned 
int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); } else { 
m_doesFlatten = true; 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)opTensor->getWidth(), (long 
unsigned int)opTensor->getHeight(), (long unsigned 
int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); } if 
(!m_doesFlatten) { m_softmaxLayer.configure(prevLayerarmTensor, 
getarmTensor()); } else { arm_compute::PermutationVector nhwcPermuteDims(2, 0, 
1), nchwPermuteDims(1, 2, 0); 
inputNHWCArmTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)ipTensor->getChannels(), (long 
unsigned int)ipTensor->getWidth(), (long unsigned int)ipTensor->getHeight(), 
1), 1, arm_compute::DataType::F32)); 
permuteToNHWC.configure(prevLayerarmTensor, &inputNHWCArmTensor, 
nhwcPermuteDims); 
tmpSfmaxNHWCArmTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)ipTensor->getChannels(), (long 
unsigned int)ipTensor->getWidth(), (long unsigned int)ipTensor->getHeight(), 
1), 1, arm_compute::DataType::F32)); 
m_softmaxLayer.configure(&inputNHWCArmTensor, &tmpSfmaxNHWCArmTensor); 
permuteToNCHW.configure(&tmpSfmaxNHWCArmTensor, getarmTensor(), 
nchwPermuteDims); } return; } void MWSoftmaxLayerImpl::allocate() { if 
(m_doesFlatten) { inputNHWCArmTensor.allocator()->allocate(); 
tmpSfmaxNHWCArmTensor.allocator()->allocate(); } MWCNNLayerImpl::allocate(); 
return; } void MWSoftmaxLayerImpl::predict() { MWSoftmaxLayer* sfmxLayer = 
static_cast<MWSoftmaxLayer*>(getLayer()); MWTensor* opTensor = 
sfmxLayer->getOutputTensor(); if (!m_doesFlatten) { m_softmaxLayer.run(); } 
else {  permuteToNHWC.run(); m_softmaxLayer.run(); permuteToNCHW.run(); }
#if MW_SFMX_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } void MWSoftmaxLayerImpl::cleanup() { if (m_doesFlatten) { 
inputNHWCArmTensor.allocator()->free(); 
tmpSfmaxNHWCArmTensor.allocator()->free(); } MWCNNLayerImpl::cleanup(); return; 
} MWAvgPoolingLayerImpl::MWAvgPoolingLayerImpl(MWCNNLayer* layer, 
MWTargetNetworkImpl* ntwk_impl, int NNhshzQGJHLSGjDiVerE,  int NmExSIssnXpisMKKatUq,  
int ONvcEjLBnVNUdjMKOAwF,  int OiVqrkNdXioJhALWMMvm,  int JsZenQeBPMhwsyEhVHiD,  
int IIiwAtyrOtLzLWAUlTey, int outBufIdx ) : MWCNNLayerImpl(layer, ntwk_impl) { 
createAvgPoolingLayer(NNhshzQGJHLSGjDiVerE, NmExSIssnXpisMKKatUq, ONvcEjLBnVNUdjMKOAwF, 
OiVqrkNdXioJhALWMMvm, JsZenQeBPMhwsyEhVHiD, JsZenQeBPMhwsyEhVHiD, 
IIiwAtyrOtLzLWAUlTey, IIiwAtyrOtLzLWAUlTey, outBufIdx); } 
MWAvgPoolingLayerImpl::~MWAvgPoolingLayerImpl() { } void 
MWAvgPoolingLayerImpl::createAvgPoolingLayer(int NNhshzQGJHLSGjDiVerE, int 
NmExSIssnXpisMKKatUq, int ONvcEjLBnVNUdjMKOAwF, int OiVqrkNdXioJhALWMMvm, int 
GZGFVDrXwFLJleoTDywO, int GFggoMvRWucDMqzlWzCl, int LklYEpYUjaLTgcFFAaJX, 
int MgAiRWiTutoTMxKXjmHQ, int outBufIdx) { MWAvgPoolingLayer* avgpoolLayer = 
static_cast<MWAvgPoolingLayer*>(getLayer()); MWTensor* opTensor = 
avgpoolLayer->getOutputTensor(); MWTensor* ipTensor = 
avgpoolLayer->getInputTensor(); opTensor->setopBufIndex(outBufIdx); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); 
getarmTensor()->allocator()->init(arm_compute::TensorInfo(arm_compute::TensorShape((long 
unsigned int)opTensor->getWidth(), (long unsigned int)opTensor->getHeight(), 
(long unsigned int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); 
m_avgPoolLayer.configure( prevLayerarmTensor, getarmTensor(), 
arm_compute::PoolingLayerInfo( arm_compute::PoolingType::AVG, NNhshzQGJHLSGjDiVerE, 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR))); return ; } 
void MWAvgPoolingLayerImpl::predict() { m_avgPoolLayer.run();
#if MW_AVG_POOL_TAP
 MWAvgPoolingLayer* avgpoolLayer = static_cast<MWAvgPoolingLayer*>(getLayer()); 
MWTensor* opTensor = avgpoolLayer->getOutputTensor(); 
mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } MWOutputLayerImpl::MWOutputLayerImpl(MWCNNLayer* layer, 
MWTargetNetworkImpl* ntwk_impl, int outbufIdx) : MWCNNLayerImpl(layer, 
ntwk_impl) { createOutputLayer(outbufIdx); } 
MWOutputLayerImpl::~MWOutputLayerImpl() { } void 
MWOutputLayerImpl::createOutputLayer( int outbufIdx) { MWOutputLayer* opLayer = 
static_cast<MWOutputLayer*>(getLayer()); MWTensor* ipTensor = 
opLayer->getInputTensor(0); MWTensor* opTensor = opLayer->getOutputTensor(0); 
m_outputData = (float*)malloc(opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth() * 
sizeof(float)); opTensor->setData(m_outputData); m_outputArmTensor = 
getprevLayerarmTensor(ipTensor); } void MWOutputLayerImpl::allocate() { 
MWOutputLayer* opLayer = static_cast<MWOutputLayer*>(getLayer()); MWTensor* 
ipTensor = opLayer->getInputTensor(0); MWTensor* opTensor = 
opLayer->getOutputTensor(0); if ((m_outputArmTensor->info()->total_size() / 4) 
== (opTensor->getBatchSize() * opTensor->getChannels() * opTensor->getHeight() 
* opTensor->getWidth())) { 
opTensor->setData((float*)m_outputArmTensor->buffer()); } 
opTensor->setData(getData<float>()); } void MWOutputLayerImpl::predict() { 
MWOutputLayer* opLayer = static_cast<MWOutputLayer*>(getLayer()); MWTensor* 
ipTensor = opLayer->getInputTensor(0); MWTensor* opTensor = 
opLayer->getOutputTensor(0); if ((m_outputArmTensor->info()->total_size() / 4) 
!= (opTensor->getBatchSize() * opTensor->getChannels() * opTensor->getHeight() 
* opTensor->getWidth())) { fillTensorToIp((unsigned 
char*)opTensor->getData<float>(), *m_outputArmTensor); } return; } void 
MWOutputLayerImpl::cleanup() { free(m_outputData); }