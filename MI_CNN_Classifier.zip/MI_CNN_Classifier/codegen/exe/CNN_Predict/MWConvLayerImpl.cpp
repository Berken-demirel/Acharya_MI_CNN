#include "MWConvLayerImpl.hpp"
#include "MWConvLayer.hpp"
#include "MWTargetNetworkImpl.hpp"
#include "cnn_api.hpp"
#include <cassert>
#include <cstring>
#include <stdio.h>
#if MW_CONV_TAP
 extern void mw_interm_tap(arm_compute::Tensor& armTensor, int size, int 
count); extern int tap_count;
#endif
 MWConvLayerImpl::MWConvLayerImpl(MWCNNLayer* layer, MWTargetNetworkImpl* 
ntwk_impl, int filt_H, int filt_W, int numGrps, int numChnls, int numFilts, int 
ONvcEjLBnVNUdjMKOAwF, int OiVqrkNdXioJhALWMMvm, int GZGFVDrXwFLJleoTDywO, int 
GFggoMvRWucDMqzlWzCl, int LklYEpYUjaLTgcFFAaJX, int MgAiRWiTutoTMxKXjmHQ, 
int BuyZFXzwOMxcePIbCLfl, int CDJtexcMbXMWAmnNZsNf, const char* 
yPBlKhIGljihkXaXbYpB, const char* UpnEytIWGokwbTFkBcSx, int outbufIdx) : 
MWCNNLayerImpl(layer, ntwk_impl) , ClEhcJFlvGCgiavziIag(filt_H) , 
CqtPRJvHlGJFssiPzsOm(filt_W) , FLuSVNoPhAFKtLUchSvv(numGrps) { 
createConvLayer(ONvcEjLBnVNUdjMKOAwF, OiVqrkNdXioJhALWMMvm, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, 
BuyZFXzwOMxcePIbCLfl,CDJtexcMbXMWAmnNZsNf, yPBlKhIGljihkXaXbYpB, 
UpnEytIWGokwbTFkBcSx,outbufIdx); } MWConvLayerImpl::~MWConvLayerImpl() { } void 
MWConvLayerImpl::createConvLayer(int ONvcEjLBnVNUdjMKOAwF, int 
OiVqrkNdXioJhALWMMvm, int GZGFVDrXwFLJleoTDywO, int GFggoMvRWucDMqzlWzCl, int 
LklYEpYUjaLTgcFFAaJX, int MgAiRWiTutoTMxKXjmHQ, int 
BuyZFXzwOMxcePIbCLfl, int CDJtexcMbXMWAmnNZsNf, const char* 
yPBlKhIGljihkXaXbYpB, const char* UpnEytIWGokwbTFkBcSx,  int outbufIdx) { 
MWConvLayer* convLayer = static_cast<MWConvLayer*>(getLayer()); MWTensor* 
ipTensor = convLayer->getInputTensor(0); MWTensor* opTensor = 
convLayer->getOutputTensor(0); 
setarmTensor(std::make_shared<arm_compute::Tensor>()); arm_compute::Tensor* 
prevLayerarmTensor = getprevLayerarmTensor(ipTensor); 
m_convLayerBiasTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)opTensor->getChannels()), 1, 
arm_compute::DataType::F32)); 
getarmTensor()->allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)opTensor->getWidth(), (long 
unsigned int)opTensor->getHeight(), (long unsigned 
int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); 
getLayer()->getOutputTensor(0)->setopBufIndex(outbufIdx); if 
(FLuSVNoPhAFKtLUchSvv != 1) { if (FLuSVNoPhAFKtLUchSvv == 
ipTensor->getChannels()) { 
m_convLayerWgtTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape( (long unsigned int)CqtPRJvHlGJFssiPzsOm, (long 
unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)opTensor->getChannels(), (long unsigned int)ipTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv), 1, arm_compute::DataType::F32)); if 
(CqtPRJvHlGJFssiPzsOm == 3 && ClEhcJFlvGCgiavziIag == 3) { 
m_depthwiseconvLayer3x3.configure( prevLayerarmTensor, &m_convLayerWgtTensor, 
&m_convLayerBiasTensor, getarmTensor(), 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR)); } else { 
m_depthwiseconvLayer.configure( prevLayerarmTensor, &m_convLayerWgtTensor, 
&m_convLayerBiasTensor, getarmTensor(), 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR)); } } else { 
m_convLayerWgtTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape( (long unsigned int)CqtPRJvHlGJFssiPzsOm, (long 
unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)ipTensor->getChannels() / FLuSVNoPhAFKtLUchSvv, (long unsigned 
int)opTensor->getChannels()), 1, arm_compute::DataType::F32)); m_prevLayer1 = 
new arm_compute::SubTensor( prevLayerarmTensor, arm_compute::TensorShape( (long 
unsigned int)ipTensor->getHeight(), (long unsigned int)ipTensor->getWidth(), 
(long unsigned int)(ipTensor->getChannels() / FLuSVNoPhAFKtLUchSvv), (long 
unsigned int)ipTensor->getBatchSize()), arm_compute::Coordinates()); 
m_prevLayer2 = new arm_compute::SubTensor( prevLayerarmTensor, 
arm_compute::TensorShape( (long unsigned int)ipTensor->getHeight(), (long 
unsigned int)ipTensor->getWidth(), (long unsigned int)(ipTensor->getChannels() 
/ FLuSVNoPhAFKtLUchSvv), (long unsigned int)ipTensor->getBatchSize()), 
arm_compute::Coordinates(0, 0, ipTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv)); m_curLayer1 = new arm_compute::SubTensor( 
getarmTensor(), arm_compute::TensorShape( (long unsigned 
int)opTensor->getWidth(), (long unsigned int)opTensor->getHeight(), (long 
unsigned int)(opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv), (long unsigned 
int)opTensor->getBatchSize()), arm_compute::Coordinates()); m_curLayer2 = new 
arm_compute::SubTensor( getarmTensor(), arm_compute::TensorShape( (long 
unsigned int)opTensor->getWidth(), (long unsigned int)opTensor->getHeight(), 
(long unsigned int)(opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv), (long 
unsigned int)opTensor->getBatchSize()), arm_compute::Coordinates(0, 0, 
opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv)); m_convLayerWgtMWTensor = new 
arm_compute::SubTensor( &m_convLayerWgtTensor, arm_compute::TensorShape( (long 
unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)CqtPRJvHlGJFssiPzsOm, (long unsigned int)(ipTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv), (long unsigned int)(opTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv)), arm_compute::Coordinates()); m_convLayerWgtTensor2 = 
new arm_compute::SubTensor( &m_convLayerWgtTensor, arm_compute::TensorShape( 
(long unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)CqtPRJvHlGJFssiPzsOm, (long unsigned int)(ipTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv), (long unsigned int)(opTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv)), arm_compute::Coordinates(0, 0, 0, 
opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv)); m_convLayerBiasMWTensor = new 
arm_compute::SubTensor( &m_convLayerBiasTensor, arm_compute::TensorShape( (long 
unsigned int)(opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv)), 
arm_compute::Coordinates()); m_convLayerBiasTensor2 = new 
arm_compute::SubTensor( &m_convLayerBiasTensor, arm_compute::TensorShape( (long 
unsigned int)(opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv)), 
arm_compute::Coordinates(opTensor->getChannels() / FLuSVNoPhAFKtLUchSvv)); 
m_convLayer.configure( m_prevLayer1, m_convLayerWgtMWTensor, 
m_convLayerBiasMWTensor, m_curLayer1, 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR), 
arm_compute::WeightsInfo(false, (long unsigned int)CqtPRJvHlGJFssiPzsOm, 
(long unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)opTensor->getChannels()) DILATED_INFO); m_convLayerSecondGroup.configure( 
m_prevLayer2, m_convLayerWgtTensor2, m_convLayerBiasTensor2, m_curLayer2, 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR), 
arm_compute::WeightsInfo(false, (long unsigned int)CqtPRJvHlGJFssiPzsOm, 
(long unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)opTensor->getChannels()) DILATED_INFO); } } else { 
m_convLayerWgtTensor.allocator()->init(arm_compute::TensorInfo( 
arm_compute::TensorShape((long unsigned int)CqtPRJvHlGJFssiPzsOm, (long 
unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)ipTensor->getChannels(), (long unsigned int)opTensor->getChannels()), 1, 
arm_compute::DataType::F32)); m_convLayer.configure( prevLayerarmTensor, 
&m_convLayerWgtTensor, &m_convLayerBiasTensor, getarmTensor(), 
arm_compute::PadStrideInfo(OiVqrkNdXioJhALWMMvm, ONvcEjLBnVNUdjMKOAwF, 
LklYEpYUjaLTgcFFAaJX, MgAiRWiTutoTMxKXjmHQ, GZGFVDrXwFLJleoTDywO, 
GFggoMvRWucDMqzlWzCl, arm_compute::DimensionRoundingType::FLOOR), 
arm_compute::WeightsInfo(false, (long unsigned int)CqtPRJvHlGJFssiPzsOm, 
(long unsigned int)ClEhcJFlvGCgiavziIag, (long unsigned 
int)opTensor->getChannels()) DILATED_INFO); } 
loadWeights(yPBlKhIGljihkXaXbYpB); loadBias(UpnEytIWGokwbTFkBcSx); return; } 
void MWConvLayerImpl::predict() { MWConvLayer* convLayer = 
static_cast<MWConvLayer*>(getLayer()); MWTensor* opTensor = 
convLayer->getOutputTensor(0); MWTensor* ipTensor = 
convLayer->getInputTensor(0); if (FLuSVNoPhAFKtLUchSvv == 1) { 
m_convLayer.run(); } else { if (FLuSVNoPhAFKtLUchSvv == 
ipTensor->getChannels()) { if (CqtPRJvHlGJFssiPzsOm == 3 && 
ClEhcJFlvGCgiavziIag == 3) { m_depthwiseconvLayer3x3.run(); } else { 
m_depthwiseconvLayer.run(); } } else { m_convLayer.run(); 
m_convLayerSecondGroup.run(); } }
#if MW_CONV_TAP
 mw_interm_tap(*getarmTensor(), opTensor->getBatchSize() * 
opTensor->getChannels() * opTensor->getHeight() * opTensor->getWidth(), tap_count++);
#endif
 return; } void MWConvLayerImpl::cleanup() { MWTensor* ipTensor = 
getLayer()->getInputTensor(); if (FLuSVNoPhAFKtLUchSvv != 1 && 
FLuSVNoPhAFKtLUchSvv != ipTensor->getChannels()) { delete m_prevLayer1; delete 
m_prevLayer2; delete m_curLayer1; delete m_curLayer2; delete 
m_convLayerWgtMWTensor; delete m_convLayerWgtTensor2; delete 
m_convLayerBiasMWTensor; delete m_convLayerBiasTensor2; } 
MWCNNLayerImpl::cleanup(); return; } void MWConvLayerImpl::loadWeights(const 
char* XCnEVUzxqcNgsuUbRonz) { MWConvLayer* convLayer = 
static_cast<MWConvLayer*>(getLayer()); MWTensor* ipTensor = 
convLayer->getInputTensor(); MWTensor* opTensor = convLayer->getOutputTensor(); 
float* wXLECKaOWaQNZlVHfnNP = (float*)malloc(ipTensor->getChannels() / 
FLuSVNoPhAFKtLUchSvv * opTensor->getChannels() * ClEhcJFlvGCgiavziIag * 
CqtPRJvHlGJFssiPzsOm * sizeof(float)); std::string fileString = 
getLinuxPath(XCnEVUzxqcNgsuUbRonz); FILE* XNZmftADYzuZnIYIpBaT = 
MWCNNLayer::openBinaryFile(fileString.c_str()); int eVAFqeShtGZAZluKdMvQ = 
ipTensor->getChannels() / FLuSVNoPhAFKtLUchSvv * opTensor->getChannels() * 
ClEhcJFlvGCgiavziIag * CqtPRJvHlGJFssiPzsOm;  call_fread(wXLECKaOWaQNZlVHfnNP, 
sizeof(float), eVAFqeShtGZAZluKdMvQ, XNZmftADYzuZnIYIpBaT, XCnEVUzxqcNgsuUbRonz); if 
(ClEhcJFlvGCgiavziIag != 1 && CqtPRJvHlGJFssiPzsOm != 1) { float* 
vjDFlBZzKvbpPseAtMBP = (float*)malloc(sizeof(float) * ClEhcJFlvGCgiavziIag * 
CqtPRJvHlGJFssiPzsOm); for (int k = 0; k < eVAFqeShtGZAZluKdMvQ / 
ClEhcJFlvGCgiavziIag / CqtPRJvHlGJFssiPzsOm; k++) { for (int i = 0; i < 
ClEhcJFlvGCgiavziIag * CqtPRJvHlGJFssiPzsOm; i++) { vjDFlBZzKvbpPseAtMBP[i] = 
wXLECKaOWaQNZlVHfnNP[k * ClEhcJFlvGCgiavziIag * CqtPRJvHlGJFssiPzsOm + i]; } for 
(int j = 0; j < ClEhcJFlvGCgiavziIag; j++) for (int i = 0; i < 
CqtPRJvHlGJFssiPzsOm; i++) { wXLECKaOWaQNZlVHfnNP[k * ClEhcJFlvGCgiavziIag * 
CqtPRJvHlGJFssiPzsOm + j * CqtPRJvHlGJFssiPzsOm + i] = vjDFlBZzKvbpPseAtMBP[j + i 
* ClEhcJFlvGCgiavziIag]; } } free(vjDFlBZzKvbpPseAtMBP); } 
m_convLayerWgtTensor.allocator()->allocate(); std::copy_n((unsigned 
char*)wXLECKaOWaQNZlVHfnNP, eVAFqeShtGZAZluKdMvQ * sizeof(float), (unsigned 
char*)m_convLayerWgtTensor.buffer()); fclose(XNZmftADYzuZnIYIpBaT); 
free(wXLECKaOWaQNZlVHfnNP); return; } void MWConvLayerImpl::loadBias(const char* 
XCnEVUzxqcNgsuUbRonz) { MWConvLayer* convLayer = 
static_cast<MWConvLayer*>(getLayer()); MWTensor* opTensor = 
convLayer->getOutputTensor(); float* URgvgDXnZskIYGdtimcU = 
(float*)malloc(opTensor->getChannels() * sizeof(float)); std::string fileString 
= getLinuxPath(XCnEVUzxqcNgsuUbRonz); FILE* XNZmftADYzuZnIYIpBaT = 
MWCNNLayer::openBinaryFile(fileString.c_str()); int eVAFqeShtGZAZluKdMvQ = 
opTensor->getChannels();  call_fread(URgvgDXnZskIYGdtimcU, sizeof(float), 
eVAFqeShtGZAZluKdMvQ, XNZmftADYzuZnIYIpBaT, XCnEVUzxqcNgsuUbRonz); 
m_convLayerBiasTensor.allocator()->allocate(); std::copy_n((unsigned 
char*)URgvgDXnZskIYGdtimcU, eVAFqeShtGZAZluKdMvQ * sizeof(float), (unsigned 
char*)m_convLayerBiasTensor.buffer()); free(URgvgDXnZskIYGdtimcU); 
fclose(XNZmftADYzuZnIYIpBaT); return; }