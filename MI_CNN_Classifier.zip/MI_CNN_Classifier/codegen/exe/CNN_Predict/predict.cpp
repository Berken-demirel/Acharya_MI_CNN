//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predict.cpp
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//

// Include Files
#include "predict.h"
#include "CNN_Predict.h"
#include "DeepLearningNetwork.h"
#include "string.h"

// Function Definitions

//
// Arguments    : b_Acharya_CNN_0 *obj
//                const real_T in[651]
//                real32_T outT[2]
// Return Type  : void
//
void DeepLearningNetwork_predict(b_Acharya_CNN_0 *obj, const real_T in[651],
  real32_T outT[2])
{
  int32_T i;
  real32_T miniBatchT[651];
  for (i = 0; i < 651; i++) {
    miniBatchT[i] = static_cast<real32_T>(in[i]);
  }

  memcpy(obj->inputData, miniBatchT, 651U * sizeof(real32_T));
  obj->predict();
  memcpy(outT, obj->outputData, 2U * sizeof(real32_T));
}

//
// File trailer for predict.cpp
//
// [EOF]
//
