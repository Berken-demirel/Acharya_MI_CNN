#include "MWTargetNetworkImpl.hpp"
#include "cnn_api.hpp"
#include "MWCNNLayerImpl.hpp"
 extern void fillTensorToIp(unsigned char*, arm_compute::ITensor&); void 
MWTargetNetworkImpl::allocate(int BufSize, int numBufsToAlloc) { numBufs = 
numBufsToAlloc; } void MWTargetNetworkImpl::postSetup(MWCNNLayer* layers[],int 
numLayers) { maxBufSize = -1; for(int i = 0; i < numLayers-1; i++) { 
if(layers[i]->getImpl() != NULL) { maxBufSize = std::max((int)maxBufSize, 
(int)((layers[i]->getImpl()->getarmTensor()->info()->total_size()) / 4)); } } 
for(int i = 0; i < numBufs; i++) { ALLOCATE_MEMORY_BUFFER(); } } float* 
MWTargetNetworkImpl::getLayerOutput(MWCNNLayer* layers[], int layerIndex, int 
portIndex) { MWTensor* opTensor = 
layers[layerIndex]->getOutputTensor(portIndex); MWCNNLayerImpl* layerImpl = 
layers[layerIndex]->getImpl(); arm_compute::Tensor* currLayerArmTensor = 
layerImpl->getarmTensor(); if (dynamic_cast<MWOutputLayerImpl*>(layerImpl)) { 
return layerImpl->getData<float>(); } else { int layerOutputSize = 
opTensor->getBatchSize() * opTensor->getChannels() * opTensor->getHeight() * 
opTensor->getWidth(); float* m_data = (float*)malloc(sizeof(float) * 
layerOutputSize); fillTensorToIp((unsigned char*)m_data, *currLayerArmTensor); 
memcpy(opTensor->getData<float>(), m_data, layerOutputSize * sizeof(float)); 
free(m_data); return opTensor->getData<float>(); } } void 
MWTargetNetworkImpl::createWorkSpace(float** zzWugmJRYlNEuAzHMpeQ) { } void 
MWTargetNetworkImpl::setWorkSpaceSize(size_t wss) { } size_t* 
MWTargetNetworkImpl::getWorkSpaceSize() { return NULL; } float* 
MWTargetNetworkImpl::getWorkSpace() { return NULL; } void 
MWTargetNetworkImpl::deallocate() { for(int i = 0; i < memBuffer.size(); i++) { 
if(memBuffer[i] != nullptr) { FREE_MEMORY_BUFFER(); } } memBuffer.clear(); } 
void MWTargetNetworkImpl::cleanup() { }