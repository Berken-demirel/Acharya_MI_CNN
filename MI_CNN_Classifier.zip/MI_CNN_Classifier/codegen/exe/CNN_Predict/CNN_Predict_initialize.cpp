//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CNN_Predict_initialize.cpp
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//

// Include Files
#include "CNN_Predict_initialize.h"
#include "CNN_Predict.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void CNN_Predict_initialize()
{
}

//
// File trailer for CNN_Predict_initialize.cpp
//
// [EOF]
//
