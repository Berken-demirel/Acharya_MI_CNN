
/* Copyright 2018 The MathWorks, Inc. */

#ifndef _MW_CONV_LAYER_IMPL
#define _MW_CONV_LAYER_IMPL

#include "MWCNNLayerImpl.hpp"

#if defined(USE_18_05_LIBRARY) | defined(USE_18_08_LIBRARY) | defined(USE_18_11_LIBRARY)  || defined(USE_19_02_LIBRARY) 
#define DILATED_INFO \
    , arm_compute::Size2D((size_t)(CDJtexcMbXMWAmnNZsNf), (size_t)(BuyZFXzwOMxcePIbCLfl))
#else
#define DILATED_INFO
#endif

// Convolution2DWCNNLayer
class MWConvLayerImpl : public MWCNNLayerImpl {
    
  private:
    int ClEhcJFlvGCgiavziIag;
    int CqtPRJvHlGJFssiPzsOm;
    int FLuSVNoPhAFKtLUchSvv;

    arm_compute::NEDepthwiseConvolutionLayer3x3 m_depthwiseconvLayer3x3; // used for Depthwise Convolution Layer with 3x3 kernels
    arm_compute::NEDepthwiseConvolutionLayer m_depthwiseconvLayer;       // used for Depthwise Convolution Layer
    arm_compute::NEConvolutionLayer m_convLayer;            // used for Convolution/1st half of grouped conv
    arm_compute::NEConvolutionLayer m_convLayerSecondGroup; // used for 2nd half of grouped conv
    arm_compute::Tensor m_convLayerWgtTensor;
    arm_compute::Tensor m_convLayerBiasTensor;
    arm_compute::SubTensor* m_prevLayer1; // subtensor for current layer input (1st half in grp conv)
    arm_compute::SubTensor* m_prevLayer2; // subtensor for current layer input (2nd half in grp conv)
    arm_compute::SubTensor* m_curLayer1;  // subtensor for current layer output (1st half in grp conv)
    arm_compute::SubTensor* m_curLayer2;  // subtensor for current layer output (2nd half in grp conv)

    arm_compute::SubTensor* m_convLayerWgtMWTensor;  // subtensor for conv weights (1st half in grp conv)
    arm_compute::SubTensor* m_convLayerWgtTensor2;   // subtensor for conv weights (2nd half in grp conv)
    arm_compute::SubTensor* m_convLayerBiasMWTensor; // subtensor for conv bias (1st half in grp conv)
    arm_compute::SubTensor* m_convLayerBiasTensor2;  // subtensor for conv bias (2nd half in grp conv)
    void createConvLayer(int, int, int, int, int, int, int, int, const char*, const char*, int);

    void predict();
    void cleanup();
    void loadWeights(const char*);
    void loadBias(const char*);

  public:
    MWConvLayerImpl(MWCNNLayer*,
                    MWTargetNetworkImpl*,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    const char*,
                    const char*,
                    int );
    ~MWConvLayerImpl();
};

#endif
