/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_CNN_Predict_api.h
 *
 * MATLAB Coder version            : 4.3
 * C/C++ source code generated on  : 28-Jun-2020 13:39:22
 */

#ifndef _CODER_CNN_PREDICT_API_H
#define _CODER_CNN_PREDICT_API_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void CNN_Predict(real_T data[651], real32_T output[2]);
extern void CNN_Predict_api(const mxArray * const prhs[1], int32_T nlhs, const
  mxArray *plhs[1]);
extern void CNN_Predict_atexit(void);
extern void CNN_Predict_initialize(void);
extern void CNN_Predict_terminate(void);
extern void CNN_Predict_xil_shutdown(void);
extern void CNN_Predict_xil_terminate(void);

#endif

/*
 * File trailer for _coder_CNN_Predict_api.h
 *
 * [EOF]
 */
