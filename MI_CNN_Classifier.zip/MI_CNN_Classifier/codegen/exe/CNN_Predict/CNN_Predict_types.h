//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CNN_Predict_types.h
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//
#ifndef CNN_PREDICT_TYPES_H
#define CNN_PREDICT_TYPES_H

// Include Files
#include "rtwtypes.h"

// Type Definitions
#include "cnn_api.hpp"
#include "MWTargetNetworkImpl.hpp"

// Type Definitions
class b_Acharya_CNN_0
{
 public:
  void presetup();
  void allocate();
  void postsetup();
  b_Acharya_CNN_0();
  void setup();
  void deallocate();
  void predict();
  void cleanup();
  real32_T *getLayerOutput(int32_T layerIndex, int32_T portIndex);
  ~b_Acharya_CNN_0();
  int32_T batchSize;
  int32_T numLayers;
  real32_T *inputData;
  real32_T *outputData;
  MWCNNLayer *layers[14];
 private:
  MWTargetNetworkImpl *targetImpl;
};

#endif

//
// File trailer for CNN_Predict_types.h
//
// [EOF]
//
