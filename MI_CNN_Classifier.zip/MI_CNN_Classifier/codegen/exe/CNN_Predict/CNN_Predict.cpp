//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: CNN_Predict.cpp
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//

// Include Files
#include "CNN_Predict.h"
#include "DeepLearningNetwork.h"
#include "predict.h"

// Function Definitions

//
// Arguments    : const real_T data[651]
//                real32_T output[2]
// Return Type  : void
//
void CNN_Predict(const real_T data[651], real32_T output[2])
{
  b_Acharya_CNN_0 net;
  DeepLearningNetwork_setup(&net);
  DeepLearningNetwork_predict(&net, data, output);

  //  hw = coder.hardware('ARM Cortex-M3 (QEMU)');
  //  cfg.Hardware = hw;
  //  cfg = coder.config('exe');
  //  cfg.TargetLang = 'C++';
  //  dlcfg = coder.DeepLearningConfig('arm-compute');
  //  dlcfg.ArmArchitecture = 'armv8';
  //  dlcfg.ArmComputeVersion = '19.02';
  //  cfg.DeepLearningConfig = dlcfg;
  //  codegen -config cfg CNN_Predict -args {XTest} -report
}

//
// File trailer for CNN_Predict.cpp
//
// [EOF]
//
