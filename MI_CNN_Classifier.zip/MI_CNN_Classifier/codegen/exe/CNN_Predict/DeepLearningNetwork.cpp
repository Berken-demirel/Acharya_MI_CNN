//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: DeepLearningNetwork.cpp
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//

// Include Files
#include "DeepLearningNetwork.h"
#include "CNN_Predict.h"

// Type Definitions
#include "MWConvLayer.hpp"
#include "cnn_api.hpp"
#include "MWTargetNetworkImpl.hpp"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : int32_T MaxBufSize
//                int32_T numBufstoAllocate
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : MWTargetNetworkImpl *targetImpl
//                MWTensor *b
//                int32_T FilterSizeH
//                int32_T FilterSizeW
//                int32_T NumChannels
//                int32_T NumFilters
//                int32_T StrideH
//                int32_T StrideW
//                int32_T PaddingH_Top
//                int32_T PaddingH_Bottom
//                int32_T PaddingW_Left
//                int32_T PaddingW_Right
//                int32_T DilationFactorH
//                int32_T DilationFactorW
//                int32_T NumGroups
//                const char * c_a___codegen_exe_CNN_Predict_c
//                const char * d_a___codegen_exe_CNN_Predict_c
//                int32_T c
// Return Type  : void
//

//
// Arguments    : MWTargetNetworkImpl *targetImpl
//                MWTensor *b
//                int32_T InputSize
//                int32_T OutputSize
//                const char * c_a___codegen_exe_CNN_Predict_c
//                const char * d_a___codegen_exe_CNN_Predict_c
//                int32_T c
// Return Type  : void
//

//
// Arguments    : MWTargetNetworkImpl *targetImpl
//                int32_T n
//                int32_T h
//                int32_T w
//                int32_T c
//                int32_T withAvg
//                const char * b
//                int32_T d
// Return Type  : void
//

//
// Arguments    : MWTargetNetworkImpl *targetImpl
//                MWTensor *b
//                int32_T c
// Return Type  : void
//

//
// Arguments    : MWTargetNetworkImpl *targetImpl
//                MWTensor *b
//                int32_T c
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : int32_T handle
// Return Type  : void
//

//
// Arguments    : MWCNNLayer *layers[14]
//                int32_T layerIdx
//                int32_T portIdx
// Return Type  : real32_T *
//

//
// Arguments    : int32_T b_index
// Return Type  : MWTensor *
//

//
// Arguments    : MWCNNLayer *layers[14]
//                int32_T numLayers
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//

//
// Arguments    : const char * name
// Return Type  : void
//

//
// Arguments    : void
// Return Type  : void
//
b_Acharya_CNN_0::b_Acharya_CNN_0()
{
  this->numLayers = 14;
  this->targetImpl = 0;
  this->layers[0] = new MWInputLayer;
  this->layers[0]->setName("imageinput");
  this->layers[1] = new MWConvLayer;
  this->layers[1]->setName("conv_1");
  this->layers[2] = new MWMaxPoolingLayer;
  this->layers[2]->setName("maxpool_1");
  this->layers[3] = new MWConvLayer;
  this->layers[3]->setName("conv_2");
  this->layers[4] = new MWMaxPoolingLayer;
  this->layers[4]->setName("maxpool_2");
  this->layers[5] = new MWConvLayer;
  this->layers[5]->setName("conv_3");
  this->layers[6] = new MWMaxPoolingLayer;
  this->layers[6]->setName("maxpool_3");
  this->layers[7] = new MWConvLayer;
  this->layers[7]->setName("conv_4");
  this->layers[8] = new MWMaxPoolingLayer;
  this->layers[8]->setName("maxpool_4");
  this->layers[9] = new MWFCLayer;
  this->layers[9]->setName("fc_1");
  this->layers[10] = new MWFCLayer;
  this->layers[10]->setName("fc_2");
  this->layers[11] = new MWFCLayer;
  this->layers[11]->setName("fc_3");
  this->layers[12] = new MWSoftmaxLayer;
  this->layers[12]->setName("softmax");
  this->layers[13] = new MWOutputLayer;
  this->layers[13]->setName("classoutput");
  this->targetImpl = new MWTargetNetworkImpl;
}

//
// Arguments    : void
// Return Type  : void
//
b_Acharya_CNN_0::~b_Acharya_CNN_0()
{
  int32_T idx;
  this->cleanup();
  for (idx = 0; idx < 14; idx++) {
    delete this->layers[idx];
  }

  if (this->targetImpl) {
    delete this->targetImpl;
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::allocate()
{
  this->targetImpl->allocate(2520, 2);
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::cleanup()
{
  int32_T idx;
  this->deallocate();
  for (idx = 0; idx < 14; idx++) {
    this->layers[idx]->cleanup();
  }

  if (this->targetImpl) {
    this->targetImpl->cleanup();
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::deallocate()
{
  this->targetImpl->deallocate();
}

//
// Arguments    : int32_T layerIndex
//                int32_T portIndex
// Return Type  : real32_T *
//
real32_T *b_Acharya_CNN_0::getLayerOutput(int32_T layerIndex, int32_T portIndex)
{
  return this->targetImpl->getLayerOutput(this->layers, layerIndex, portIndex);
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::postsetup()
{
  int32_T idx;
  this->targetImpl->postSetup(this->layers, this->numLayers);
  for (idx = 0; idx < 14; idx++) {
    this->layers[idx]->allocate();
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::predict()
{
  int32_T idx;
  for (idx = 0; idx < 14; idx++) {
    this->layers[idx]->predict();
  }
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::presetup()
{
  this->targetImpl->preSetup();
}

//
// Arguments    : void
// Return Type  : void
//
void b_Acharya_CNN_0::setup()
{
  this->presetup();
  this->allocate();
  (dynamic_cast<MWInputLayer *>(this->layers[0]))->createInputLayer
    (this->targetImpl, 1, 1, 651, 1, 0, "", 0);
  (dynamic_cast<MWConvLayer *>(this->layers[1]))->createConvLayer
    (this->targetImpl, this->layers[0]->getOutputTensor(0), 1, 102, 1, 3, 1, 1,
     0, 0, 0, 0, 1, 1, 1, "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_1_w",
     "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_1_b", 1);
  (dynamic_cast<MWMaxPoolingLayer *>(this->layers[2]))->createMaxPoolingLayer
    (this->targetImpl, this->layers[1]->getOutputTensor(0), 1, 2, 2, 2, 0, 0, 0,
     0, 0, 1, 0);
  (dynamic_cast<MWConvLayer *>(this->layers[3]))->createConvLayer
    (this->targetImpl, this->layers[2]->getOutputTensor(0), 1, 24, 3, 10, 1, 1,
     0, 0, 0, 0, 1, 1, 1, "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_2_w",
     "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_2_b", 1);
  (dynamic_cast<MWMaxPoolingLayer *>(this->layers[4]))->createMaxPoolingLayer
    (this->targetImpl, this->layers[3]->getOutputTensor(0), 1, 2, 2, 2, 0, 0, 0,
     0, 0, 1, 0);
  (dynamic_cast<MWConvLayer *>(this->layers[5]))->createConvLayer
    (this->targetImpl, this->layers[4]->getOutputTensor(0), 1, 11, 10, 10, 1, 1,
     0, 0, 0, 0, 1, 1, 1, "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_3_w",
     "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_3_b", 1);
  (dynamic_cast<MWMaxPoolingLayer *>(this->layers[6]))->createMaxPoolingLayer
    (this->targetImpl, this->layers[5]->getOutputTensor(0), 1, 2, 2, 2, 0, 0, 0,
     0, 0, 1, 0);
  (dynamic_cast<MWConvLayer *>(this->layers[7]))->createConvLayer
    (this->targetImpl, this->layers[6]->getOutputTensor(0), 1, 9, 10, 10, 1, 1,
     0, 0, 0, 0, 1, 1, 1, "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_4_w",
     "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_conv_4_b", 1);
  (dynamic_cast<MWMaxPoolingLayer *>(this->layers[8]))->createMaxPoolingLayer
    (this->targetImpl, this->layers[7]->getOutputTensor(0), 1, 2, 2, 2, 0, 0, 0,
     0, 0, 1, 0);
  (dynamic_cast<MWFCLayer *>(this->layers[9]))->createFCLayer(this->targetImpl,
    this->layers[8]->getOutputTensor(0), 250, 30,
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_1_w",
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_1_b", 1);
  (dynamic_cast<MWFCLayer *>(this->layers[10]))->createFCLayer(this->targetImpl,
    this->layers[9]->getOutputTensor(0), 30, 10,
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_2_w",
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_2_b", 0);
  (dynamic_cast<MWFCLayer *>(this->layers[11]))->createFCLayer(this->targetImpl,
    this->layers[10]->getOutputTensor(0), 10, 2,
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_3_w",
    "./codegen/exe/CNN_Predict/cnn_Acharya_CNN_fc_3_b", 1);
  (dynamic_cast<MWSoftmaxLayer *>(this->layers[12]))->createSoftmaxLayer
    (this->targetImpl, this->layers[11]->getOutputTensor(0), 0);
  (dynamic_cast<MWOutputLayer *>(this->layers[13]))->createOutputLayer
    (this->targetImpl, this->layers[12]->getOutputTensor(0), 0);
  this->postsetup();
  this->inputData = this->layers[0]->getLayerOutput(0);
  this->outputData = this->layers[13]->getLayerOutput(0);
}

//
// Arguments    : b_Acharya_CNN_0 *obj
// Return Type  : void
//
void DeepLearningNetwork_setup(b_Acharya_CNN_0 *obj)
{
  obj->setup();
  obj->batchSize = 1;
}

//
// File trailer for DeepLearningNetwork.cpp
//
// [EOF]
//
