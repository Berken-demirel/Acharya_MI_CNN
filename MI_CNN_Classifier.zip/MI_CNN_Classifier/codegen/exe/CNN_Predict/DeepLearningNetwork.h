//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: DeepLearningNetwork.h
//
// MATLAB Coder version            : 4.3
// C/C++ source code generated on  : 28-Jun-2020 13:39:22
//
#ifndef DEEPLEARNINGNETWORK_H
#define DEEPLEARNINGNETWORK_H

// Include Files
#include <cstddef>
#include <cstdlib>
#include "rtwtypes.h"
#include "CNN_Predict_types.h"

// Type Definitions
#include "MWConvLayer.hpp"
#include "cnn_api.hpp"
#include "MWTargetNetworkImpl.hpp"

// Function Declarations
extern void DeepLearningNetwork_setup(b_Acharya_CNN_0 *obj);

#endif

//
// File trailer for DeepLearningNetwork.h
//
// [EOF]
//
