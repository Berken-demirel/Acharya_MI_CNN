%% Berken Utku Demirel
clearvars
clc
close all
%% Load data
XTest = load('Test_data.mat').Test_data; 
% Call the function
XTest = XTest(1,:);
XTest = reshape(XTest,1,651,1);
output = CNN_Predict(XTest);