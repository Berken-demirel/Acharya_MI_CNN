function output = CNN_Predict(data)
net = coder.loadDeepLearningNetwork('Acharya_CNN.mat','Acharya_CNN');
output = predict(net,data);
end


% hw = coder.hardware('ARM Cortex-M3 (QEMU)');
% cfg.Hardware = hw;
% cfg = coder.config('exe');
% cfg.TargetLang = 'C++';
% dlcfg = coder.DeepLearningConfig('arm-compute');
% dlcfg.ArmArchitecture = 'armv8';
% dlcfg.ArmComputeVersion = '19.02';
% cfg.DeepLearningConfig = dlcfg;
% codegen -config cfg CNN_Predict -args {XTest} -report